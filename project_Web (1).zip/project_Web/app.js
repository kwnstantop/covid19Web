
const express = require('express')
const app = express()
const port = 4000;
var path = require('path');
const { db } = require('./database.js')
const bodyParser = require('body-parser');

var ejs = require('ejs');

const fileUpload = require('express-fileupload');


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(fileUpload());

app.set('view engine', 'ejs')
app.set('views', './views')
app.use('/public', express.static(path.join(__dirname, "public")));

var user = {
    user_id: '',
}

function dateCheck(from, to, check) {
    console.log({ from, to, check });
    if ((check <= to && check >= from)) {
        return true;
    }
    return false;
}


app.get('/', (req, res) => {
    res.render('login') // render login page
})

app.get('/register', (req, res) => {
    res.render('register') // render register page
})

app.get('/page', (req, res) => {
    res.render('page') // render page page
})

app.get('/admin', (req, res) => {
    res.render('admin') // render admin page
})

app.get('/edit', (req, res) => {
    res.render('edit') // render edit page
})


app.listen(port, () => {
    console.log(`App listening on port ${port}`) // listen on port 4000
})


app.post('/login', async function (req, res) {
    const email = req.body.email
    const password = req.body.password

    const sql = `SELECT * FROM user WHERE email='${email}' AND password='${password}'`;
    let response;
    try {
        response = await db.query(sql);
    } catch (error) {
        console.log(error);
    }
    if (response[0].length > 0) {
        const loggedUser = response[0][0];
        user = { ...loggedUser };
        console.log(user);
        if (loggedUser.admin) {
            res.redirect('/admin')
        } else {
            res.redirect('/page')
        }
    } else {
        res.status(401).send('Λάθος email ή password');
    }


})

app.post('/register', async function (req, res) {
    console.log(db.PromisePool);
    const username = req.body.username
    const password = req.body.password
    const email = req.body.email

    let response;
    try {
        response = await db.query(`INSERT INTO user(username, password, email, admin) VALUES('${username}','${password}','${email}', 0)`);
        res.send('ΟΚ')
    } catch (error) {
        console.log(error);
        if (error.code == 'ER_DUP_ENTRY' || error.errno == 1062) {
            res.status(400).send('Το email υπάρχει ήδη');
        }
    }
})


app.post('/upload', async function (req, res) {
    let json = req.files.file;
    const jsonData = JSON.parse(json.data)
    console.log(jsonData);
    const necessaryData = jsonData.map(x => {
        return {
            id: x.id,
            name: x.name,
            address: x.address,
            types: x.types,
            coordinates: x.coordinates,
            populartimes: x.populartimes
        }
    });
    let resp;
    necessaryData.map(async x => {
        const sqlQueryString = `INSERT INTO point_of_interest(name, address,coordinates, types, populartimes) VALUES('${x.name}', '${x.address}', Point(${x.coordinates.lat}, ${x.coordinates.lng}), '${JSON.stringify(x.types)}', '${JSON.stringify(x.populartimes)}')`;
        try {
            resp = await db.query(sqlQueryString);
        } catch (error) {
        }
    })
    res.send();
})


app.post('/deleteData', async function (req, res) {
    const sqlQueryString1 = `DELETE FROM point_of_interest`;
    const sqlQueryString2 = `DELETE FROM user where admin=0`;
    const sqlQueryString3 = `DELETE FROM user_visit_place`;
    const sqlQueryString4 = `DELETE FROM user_positive_date`;
    let resp;
    try {
        resp = await db.query(sqlQueryString3);
        resp = await db.query(sqlQueryString1);
        resp = await db.query(sqlQueryString4);
        resp = await db.query(sqlQueryString2);
        res.send('ok');
    } catch (error) {
        res.status(500).send()
        throw error
    }
})

app.get('/searchType', async function (req, res) {

    const name = req.query.name; // Παίρνουμε το name από το query string, καθώς κάνουμε get request
    const sqlQueryString = `SELECT * FROM point_of_interest where types like '%${name}%'`; // Κάνουμε το query
    let resp;
    try {
        resp = await db.query(sqlQueryString); // Εκτελούμε το query
    } catch (error) {
        res.status(500).send() // Αν υπάρξει κάποιο error, στέλνουμε status 500
        throw error
    }
    res.send(resp[0]);  // Αν δεν υπάρξει κάποιο error, στέλνουμε το αποτέλεσμα του query που περιέχει τα στοιχεία του συγκεκριμένου σημείου ενδιαφέροντος

})

app.post('/presense_inform', async function (req, res) {
    const point_id = req.body.point_id;
    const num_of_people = req.body.num_of_people;
    try {
        const sqlWithNumOfPeople = `insert into user_visit_place(user_id, poi_id, num_of_users, timestamp)
            values(${user.user_id}, ${point_id}, ${num_of_people}, now())`;  // Εισαγωγή στον πίνακα user_visit_place

        const sqlWithoutNumOfPeople = `insert into user_visit_place(user_id, poi_id, timestamp)
        values(${user.user_id}, ${point_id}, now())` // Εισαγωγή στον πίνακα user_visit_place

        await db.query(num_of_people ? sqlWithNumOfPeople : sqlWithoutNumOfPeople); // if num_of_people is not null then insert with num_of_people else insert without num_of_people

        res.send('ok')
    } catch (error) {
        console.log(error);
        res.status(500).send()
    }

})

app.post('/imPositive', async function (req, res) {

    const covid_date = req.body.covid_date;

    const dbResp1 = await db.query(`select positive_date from user_positive_date where user_id='${user.user_id || 1}'`)
    if (dbResp1[0].length > 0) { // αν ο χρήστης έχει ήδη καταχωρηθεί ως θετικός τουλάχιστον μία φορά 
        const positive_date = new Date(dbResp1[0][0].positive_date)
        const days7 = 604800000; // in milliseconds
        const days14 = days7 * 2;
        const isBetween = dateCheck(new Date(positive_date - days7), new Date(positive_date + days14), new Date(covid_date))
        if (isBetween) { // τσέκαρε αν η ημερομηνία που έδωσε ο χρήστης είναι μεταξύ 7 και 14 ημερών από την πρώτη θετική του αποτέλεσματος
            res.status(400).json('Έχετε ήδη δηλώσει στο διάστημα [-7, +14] ')
        }
        else { // αν όχι τότε κάνε νέα εγγραφή την ημερομηνία του
            await db.query(`insert into user_positive_date(user_id, positive_date) values(${user.user_id || 1}, STR_TO_DATE('${covid_date}', '%Y-%m-%d'))`)
            res.json('Ευχαριστούμε που κρατάτε την πόλη ασφαλή')
        }
    }
    else { // αν ο χρήστης δεν έχει καταχωρηθεί ως θετικός τότε κάνε νέα εγγραφή την ημερομηνία του
        try {
            await db.query(`insert into user_positive_date(user_id, positive_date) values(${user.user_id || 1}, STR_TO_DATE('${covid_date}', '%Y-%m-%d'))`)
            res.json('Ευχαριστούμε που κρατάτε την πόλη ασφαλή')
        } catch (error) {
            console.log(error);
            res.status(500).json('Κάτι πήγε στραβά');
        }
    }


})

app.post('/edit', async function (req, res) {
    console.log(req.body);
    const username = req.body.username; // ονομα χρήστη
    const password = req.body.password; // κωδικός χρήστη
    const email = req.body.email; // email χρήστη
    const user_id = user.user_id; // id χρήστη 
    try {
        const sql = `UPDATE user SET username='${username}', password='${password}', email='${email}' WHERE user_id=${user_id}` // ενημέρωσε τα στοιχεία του χρήστη
        const dbresp = await db.query(sql) // εκτέλεσε το query
        res.send('ok') // στείλε ok
    } catch (error) { // αν υπάρχει κάποιο σφάλμα
        console.log(error);
        res.status(500).send() // στείλε 500
    }
})

app.get('/visited_places', async function (req, res) {
    try {

        const sql = `SELECT user_visit_place.poi_id, num_of_users, timestamp, name
        FROM user_visit_place
        INNER JOIN point_of_interest  ON user_visit_place.poi_id = point_of_interest.poi_id WHERE
        user_id=${user.user_id}` // επέλεξε όλα τα στοιχεία των μέρων που έχει επισκεφτεί ο χρήστης
        const dbresp = await db.query(sql) // εκτέλεσε το query

        res.json(dbresp[0]) // στείλε τα αποτελέσματα
    } catch (error) {
        console.log(error);
        res.status(500).send()
    }
})

app.get('/stats', async function (req, res) {
    // get number of total visits
    const sql = `SELECT COUNT(*) as total_visits FROM user_visit_place`
    const dbresp = await db.query(sql)
    const total_visits = dbresp[0][0].total_visits

    // get number of total covid infections
    const sql2 = `SELECT COUNT(*) as total_infections FROM user_positive_date`
    const dbresp2 = await db.query(sql2)
    const total_infections = dbresp2[0][0].total_infections

    // get number of infected_users visiting a place in between 7 days before and 14 days after infection
    const sql3 = `SELECT COUNT(*) as infected_users FROM user_visit_place
    INNER JOIN user_positive_date ON user_visit_place.user_id = user_positive_date.user_id
    WHERE user_visit_place.timestamp BETWEEN DATE_SUB(user_positive_date.positive_date, INTERVAL 7 DAY) AND DATE_ADD(user_positive_date.positive_date, INTERVAL 14 DAY)`
    const dbresp3 = await db.query(sql3)
    const infected_users = dbresp3[0][0].infected_users



    // rank each type which is a array of strings by number of infected users visits in between 7 days before and 14 days after infection
    const sql5 = `SELECT types, COUNT(*) as numOfInfectedUsers
    FROM user_visit_place
    INNER JOIN user_positive_date ON user_visit_place.user_id = user_positive_date.user_id
    INNER JOIN point_of_interest ON user_visit_place.poi_id = point_of_interest.poi_id
    WHERE user_visit_place.timestamp BETWEEN DATE_SUB(user_positive_date.positive_date, INTERVAL 7 DAY) AND DATE_ADD(user_positive_date.positive_date, INTERVAL 14 DAY)
    GROUP BY types ORDER BY numOfInfectedUsers DESC`
    const dbresp5 = await db.query(sql5)
    const types = dbresp5[0]

    const parsedTypes = types.map(ent => {
        return {
            types: JSON.parse(ent.types), // array of types strings
            numOfInfectedUsers: ent.numOfInfectedUsers // number of infected users
        }
    });


    const infectedTypesNumOfVisits = []

    parsedTypes.map(ent => { // for element in parsedTypes
        ent.types.map(type => { // for each type string in types
            const index = infectedTypesNumOfVisits.findIndex(ent => ent.type === type)  // find index of type in infectedTypesArray
            if (index === -1) { // if type is not in infectedTypesArray
                infectedTypesNumOfVisits.push({  // push type and numOfInfectedUsers
                    type,
                    numOfInfectedUsers: ent.numOfInfectedUsers
                })
            }
            else {
                infectedTypesNumOfVisits[index].numOfInfectedUsers += ent.numOfInfectedUsers // else add numOfInfectedUsers to type
            }
        })
    })




    // rank each type which is a array of strings by number of users visits
    const sql6 = `SELECT types, COUNT(*) as numOfVisits
        FROM user_visit_place
        INNER JOIN point_of_interest
        ON user_visit_place.poi_id = point_of_interest.poi_id
        GROUP BY types ORDER BY numOfVisits DESC`;
    const dbresp6 = await db.query(sql6);
    const typesOfPlaces = dbresp6[0];
    const parsedTypesOfPlaces = typesOfPlaces.map(ent => {
        return {
            types: JSON.parse(ent.types), // array of types strings
            numOfVisits: ent.numOfVisits // number of users
        }
    });

    const typesNumOfVisits = []
    parsedTypesOfPlaces.map(ent => { // for element in parsedTypes
        ent.types.map(type => { // for each type string in types
            const index = typesNumOfVisits.findIndex(ent => ent.type === type)  // find index of type in infectedTypesArray
            if (index === -1) { // if type is not in infectedTypesArray
                typesNumOfVisits.push({  // push type and numOfInfectedUsers
                    type,
                    numOfVisits: ent.numOfVisits
                })
            }
            else {
                typesNumOfVisits[index].numOfVisits += ent.numOfVisits // else add numOfInfectedUsers to type
            }
        })
    })


    res.json({
        total_visits,
        total_infections,
        infected_users,
        infectedTypesNumOfVisits,
        typesNumOfVisits,
    }) // στείλε τα αποτελέσματα
})

app.get('/check_if_got_in_touch_with_an_infected_user', async function (req, res) {
    try {

        // check if people who visited the same place with me had covid the last 7 days and time between visits is is 2 hours less or more than my visit
        const sql = `
        SELECT a.user_id as searched_user, b.user_id as random_infected_user, name from user_visit_place a
        INNER JOIN user_visit_place b ON a.poi_id = b.poi_id and a.user_id != b.user_id
        INNER JOIN user_positive_date c ON b.user_id = c.user_id
        INNER JOIN point_of_interest d ON a.poi_id = d.poi_id
        WHERE a.user_id = ${user.user_id || 8} and c.positive_date BETWEEN DATE_SUB(NOW(), INTERVAL 7 DAY) AND NOW()
        AND TIMESTAMPDIFF(HOUR, a.timestamp, b.timestamp) BETWEEN -2 AND 2`
        const dbresp = await db.query(sql)
        const infected_users = dbresp[0]
        res.json({
            infected_users,
            gotInTouch: infected_users.length > 0
        })
    } catch (error) {
        console.log(error);
        res.status(500).send()
    }
})
