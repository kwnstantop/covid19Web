drop table if exists `point_of_interest`;
  CREATE TABLE IF NOT EXISTS `point_of_interest` (
    `poi_id` int(11) NOT NULL auto_increment
    ,`name` varchar(20) 
    ,`types` JSON
    ,`address` varchar(20) 
    ,`coordinates` Point NOT NULL UNIQUE
    ,`populartimes` JSON NOT NULL
    ,PRIMARY KEY (`poi_id`)
  ) ENGINE=InnoDB COLLATE=utf8_unicode_ci;

    drop table if exists `user`;
    CREATE TABLE IF NOT EXISTS `user` (
    `user_id` int(11) NOT NULL auto_increment
    ,`username` varchar(20) NOT NULL
    ,`password` varchar(20) NOT NULL
    ,`email` varchar(20) NOT NULL UNIQUE
    ,`admin` TINYINT(1) NOT NULL
    ,PRIMARY KEY (`user_id`)
  ) ENGINE=InnoDB COLLATE=utf8_unicode_ci;

  CREATE TABLE IF NOT EXISTS `user_visit_place` (
    `id` int(11) NOT NULL auto_increment
    ,`user_id` int(11) NOT NULL
    ,`poi_id` int(11) NOT NULL
    ,`num_of_users` int(11)
    ,`timestamp` DATETIME NOT NULL
    , PRIMARY KEY (`id`)
    , FOREIGN KEY (poi_id) REFERENCES point_of_interest (poi_id) 
    , FOREIGN KEY (user_id) REFERENCES user (user_id) 
  ) ENGINE=InnoDB COLLATE=utf8_unicode_ci;


    CREATE TABLE IF NOT EXISTS `user_positive_date` (
     `id` int(11) NOT NULL auto_increment
    ,`user_id` int(11) NOT NULL
    , `positive_date` date not null
    , PRIMARY KEY(`id`)
    , FOREIGN KEY (user_id) REFERENCES user(user_id) 
    )


  INSERT INTO user(username, email, `password`, `admin`) values ('admin', 'admin@admin.admin', 'admin', 1 )